from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from tools.analysis.imports import run_import_linter

from tools.common import ErrorLog
from tools.setup.config import BootstrapConfig
from tools.setup.profile import PyProjectProfile, load_pyproject_profile
from tools.ui import SetupConsole, StepProgress
from tools.ui.resources import TextCatalog
from venv import create as venv_create

_TEXTS = TextCatalog()


def _check_python_version(profile: PyProjectProfile) -> bool:
    """Prüft, ob die laufende Python-Version die Mindestanforderung erfüllt."""
    if profile.requires_min_python is None:
        return True
    major, minor = profile.requires_min_python
    if sys.version_info[:2] < (major, minor):
        SetupConsole.error(
            f"Python {major}.{minor} oder neuer erforderlich, gefunden: "
            f"{sys.version_info.major}.{sys.version_info.minor}",
        )
        return False
    return True


def _create_venv(config: BootstrapConfig) -> bool:
    """Erzeugt das virtuelle Environment, falls noch nicht vorhanden."""
    if config.venv_dir.exists():
        SetupConsole.info(f"Virtuelle Umgebung existiert bereits: {config.venv_dir}")
        return True

    SetupConsole.info(f"Erzeuge virtuelle Umgebung in {config.venv_dir} ...")
    venv_create(config.venv_dir, with_pip=True)
    return True


def _install_requirements_batch(
    python_venv: str,
    requirements: dict[str, str],
    category_name: str,
    success_message: str,
    log: ErrorLog,
) -> bool:
    """Installiert eine Gruppe von Requirements mit Progress-Bar."""
    total = len(requirements)
    if total == 0:
        SetupConsole.warning(f"Keine {category_name}-Pakete gefunden.")
        return True

    SetupConsole.info(f"Pakete werden geladen... ({category_name}, {total} Einträge)")

    installed = 0
    with StepProgress(f"{category_name}-Installation", total=total) as progress:
        for name, version_spec in requirements.items():
            spec = f"{name}{version_spec}"

            # Text über dem Balken: "Paket: <name>"
            progress.set_status(f"Paket: {name}")

            try:
                subprocess.run(
                    [python_venv, "-m", "pip", "install", spec, "--progress-bar", "off"],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                installed += 1
                progress.advance()
            except subprocess.CalledProcessError as exc:
                SetupConsole.error(f"Fehler bei der Installation von {spec}")
                msg = exc.stderr or exc.stdout or str(exc)
                if msg:
                    SetupConsole.info(msg)
                log.write_error(
                    f"{category_name} Installation: {spec}",
                    f"Fehler beim Installieren von {spec}",
                    details=(exc.stdout or "") + (exc.stderr or ""),
                )
                return False

    SetupConsole.success(f"{success_message.strip()} ({installed}/{total})\n")
    return True


def _install_all_dependencies(
    config: BootstrapConfig,
    profile: PyProjectProfile,
    log: ErrorLog,
) -> bool:
    """Installiert Runtime- und Dev-Abhängigkeiten."""
    python_venv = config.venv_python

    if not _install_requirements_batch(
        python_venv,
        profile.runtime_requirements,
        "Runtime-Dependencies",
        "Runtime-Dependencies installiert",
        log,
    ):
        return False

    if not profile.dev_requirements:
        return True

    return _install_requirements_batch(
        python_venv,
        profile.dev_requirements,
        "Dev-Dependencies",
        "Dev-Dependencies installiert",
        log,
    )

def _run_import_checks(config: BootstrapConfig, profile: PyProjectProfile, log: ErrorLog) -> bool:
    """Führt Import-Linter aus, falls im Profil aktiviert.

    Gibt bei Fehlern eine generische Beschreibung plus einen Auszug der
    Original-Ausgabe aus und schreibt alles ins Log.
    """
    if not profile.uses_import_linter:
        return True

    SetupConsole.info("Starte Import-Prüfung (import-linter)...")

    ok, output = run_import_linter(config.venv_python, config.repo_root)

    if ok:
        SetupConsole.info(_TEXTS.text("import_linter", field="success"))
        return True

    # Generische Fehlermeldung
    SetupConsole.error(_TEXTS.text("import_linter", field="failed"))

    # Kurzbeschreibung nach Muster – aber bewusst simpel gehalten
    text_lower = output.lower()
    if "no module named" in text_lower and "importlinter" in text_lower:
        human = (
            "Import-Linter ist installiert, aber das CLI-Modul konnte nicht "
            "korrekt ausgeführt werden (fehlende __main__-Konfiguration)."
        )
    else:
        human = (
            "Import-Linter hat entweder Contract-Verstöße gemeldet oder ist "
            "mit einem Fehler beendet worden."
        )

    SetupConsole.info(human)

    if output.strip():
        first_lines = "\n".join(output.strip().splitlines()[:10])
        SetupConsole.info(first_lines)

    log.write_error(
        "Import-Linter",
        human,
        output or "keine Ausgabe von Import-Linter",
    )
    return False


def _run_tests(config: BootstrapConfig, profile: PyProjectProfile, log: ErrorLog) -> bool:
    """Führt pytest aus, falls im Profil aktiviert und nicht übersprungen."""
    if not profile.uses_pytest:
        return True
    if config.skip_tests:
        SetupConsole.info(_TEXTS.text("tests", field="skipped_hint"))
        return True

    python_venv = config.venv_python
    SetupConsole.info("Starte Tests mit pytest...")

    with StepProgress("Testausführung", total=1) as progress:
        progress.set_status("pytest wird ausgeführt...")
        try:
            subprocess.run(
                [python_venv, "-m", "pytest"],
                check=True,
            )
            progress.advance(status="pytest erfolgreich")
            SetupConsole.info(_TEXTS.text("tests", field="success_hint"))
            return True
        except subprocess.CalledProcessError as exc:
            progress.advance(status="pytest fehlgeschlagen")
            SetupConsole.error(_TEXTS.text("tests", field="failed_hint"))
            log.write_error("pytest", "Tests fehlgeschlagen", str(exc))
            return False


def main(argv: list[str] | None = None) -> int:
    """Haupteinstieg für das Setup (wird von setup.py aufgerufen)."""
    args = list(sys.argv[1:] if argv is None else argv)
    skip_tests = "--skip-tests" in args
    if skip_tests:
        args.remove("--skip-tests")

    config = BootstrapConfig(skip_tests=skip_tests)
    profile = load_pyproject_profile()
    log = ErrorLog(config.log_path)

    # Header & Legende
    SetupConsole.header(_TEXTS.text("setup_header", field="title"))
    SetupConsole.info(_TEXTS.text("setup_header", field="intro"))
    SetupConsole.legend()
    SetupConsole.info(f"Betriebssystem: {sys.platform}\n")

    # Schritt 1: Python-Version + venv
    if not _check_python_version(profile):
        return 1
    if not _create_venv(config):
        return 1

    # Schritt 2: Dependencies
    if not _install_all_dependencies(config, profile, log):
        SetupConsole.from_resource("troubleshooting")
        return 1

    # Schritt 3: Import-Checks
    if not _run_import_checks(config, profile, log):
        SetupConsole.from_resource("troubleshooting")
        return 1

    # Schritt 4: Tests
    if not _run_tests(config, profile, log):
        SetupConsole.from_resource("troubleshooting")
        return 1

    # Abschluss
    SetupConsole.from_resource("next_steps")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())