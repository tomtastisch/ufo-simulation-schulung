from __future__ import annotations

from .bootstrap import main as run_setup

__all__ = ["run_setup"]