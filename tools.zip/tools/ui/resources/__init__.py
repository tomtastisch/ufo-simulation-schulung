from __future__ import annotations

from .catalog import TextCatalog

__all__ = ["TextCatalog"]