from __future__ import annotations

"""Analyse-Werkzeuge (z. B. Import-Checks) für die UFO-Simulation."""